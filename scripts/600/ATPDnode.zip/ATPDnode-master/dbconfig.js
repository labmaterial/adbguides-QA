module.exports= {
dbuser:"username",
dbpassword:"password",
connectString :"connectString"
}
