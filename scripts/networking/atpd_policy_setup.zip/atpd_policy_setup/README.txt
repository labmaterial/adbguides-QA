ATPD policy setup script is a python application that helps you to setup access policy for ATPD cloud service.
It provides simple yaml file under <UNZIPPED_LOCATION>/atpd_policy_setup/yaml_templates folder. This file can
be updated to define users, groups to manage ATPD fleet and databases. The execution of setup script then takes
care of adding required policies to each group defining access rules as per recommendation.

Steps to execute atpd_policy_setup script
Prerequisites:
  * Make sure to have following software dependencies
    - Python 2.7 or higher version
    - Python package installer 'pip' (Refer 'Note 4' to know the steps to install 'pip')
    - Python virtual environment 'virtualenv' if python version starts with 2.*. (Refer 'Note 4' to know the steps to install virtualenv)
  * Make sure to have network connection to be able to download python OCI SDK, and to be able to access OCI tenancy.

Step 1: Fill the required values in <UNZIPPED_LOCATION>/atpd_policy_setup/yaml_templates/atpd_access_config.yaml
        - Specify all values as string. It is recommended to specify values within double quote.
        - For all map or dictionary values, use a colon and space (“: ”) to mark each key: value pair.
Step 2: Run setup.sh by passing updated yaml file location (Use setup.bat script to execute on Windows OS).
        <UNZIPPED_LOCATION>/atpd_policy_setup/setup.sh --yaml_template=<UNZIPPED_LOCATION>/atpd_policy_setup/yaml_templates/atpd_access_config.yaml

Note:
1. The logs for the execution are kept under <UNZIPPED_LOCATION>/atpd_policy_setup/logs directory.
2. A directory pyenv is created under <UNZIPPED_LOCATION>/atpd_policy_setup that has python virtual environment, and
   is required during the execution. This directory may be deleted after the execution of the script.
3. If you want to just generate the policies without creating them in the tenancy, execute following command:
   <UNZIPPED_LOCATION>/atpd_policy_setup/setup.sh --yaml_template=<UNZIPPED_LOCATION>/atpd_policy_setup/yaml_templates/atpd_access_config.yaml --generate_policies
   The above command will generate the yaml file in the directory <UNZIPPED_LOCATION>/atpd_policy_setup/yaml_templates  which includes resulting policies.
   You can add additional policies and pass this file to setup.sh to create custom policies.
4. Following steps can be referred to install pip and virtualenv
   - Download get-pip.py by executing the command "curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py"
   - Execute get-pip.py using command "sudo python get-pip.py"
   - Install virtualenv using command "sudo pip install virtualenv"
   - More information can be found in the URLs
     pip : https://pip.pypa.io/en/stable/installing/
     virtualenv : https://virtualenv.pypa.io/en/latest/installation/
5. The OCI credentials for the execution will be read in the following order:
   - From the provided YAML file
   - From the default template located at: UNZIPPED_LOCATION>/atpd_policy_setup/yaml_templates/atpd_access_config.yaml
   - From the default OCI configuration location: ~/.oci/config
