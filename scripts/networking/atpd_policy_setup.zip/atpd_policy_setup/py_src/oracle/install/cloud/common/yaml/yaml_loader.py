import logging

import yaml

from oracle.install.cloud.common.resource.atpd_exception import ATPDException
from oracle.install.cloud.common.resource.user_messages import UserMessages


class YAMLLoader:
    """
    Load YAML file
    """

    def load_yaml(self,yaml_file):
        """
        Read and convert YAML file to python object
        :param yaml_file: (str) YAML path
        :return: (dir) Python object
        """
        with open(yaml_file, 'r') as file:
            try:
                input_obj = yaml.safe_load(file)
                return input_obj
            except yaml.YAMLError as err:
                logging.error("Exception occurred while loading yaml file:"+yaml_file)
                logging.error(err, exc_info=True)
                raise ATPDException(UserMessages.format_message(UserMessages.YAML_VALIDATOR_MALFORMED_YAML))

