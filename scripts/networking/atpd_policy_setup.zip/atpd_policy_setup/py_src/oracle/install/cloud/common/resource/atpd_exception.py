
class ATPDException(Exception):
    """
    Defines a custom ATPD Exception type
    """
    pass
