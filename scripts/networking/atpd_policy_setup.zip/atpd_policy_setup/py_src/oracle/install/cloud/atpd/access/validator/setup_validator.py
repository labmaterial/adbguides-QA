import logging

from oracle.install.cloud.atpd.access.resource.setup_constants import SetupConstants
from oracle.install.cloud.common.oci.oci_identity_handler import OCIIdentityHandler
from oracle.install.cloud.common.resource.atpd_exception import ATPDException
from oracle.install.cloud.common.resource.user_messages import UserMessages
from oracle.install.cloud.common.variable.variable_handler import VariableHandler


class SetupValidator:
    """
    Validates YAML script and OCI connection
    """

    def validate(self,raw_data):
        """
        Validate mandatory fields and variables
        :param raw_data: (dict)
        :return:
        """
        if not raw_data:
            raise ATPDException(UserMessages.format_message(UserMessages.NO_INPUT_DATA_ERR))
        self.validate_mandatory_fields(raw_data)
        self.validate_variables(raw_data)

    def validate_variables(self,raw_data):
        """
        Validate variables
        :param raw_data: (dict)
        :return:
        """
        if raw_data:
            VariableHandler().validate(raw_data)
        else:
            logging.warning("Raw data is empty. So skiping validation")

    # def _validate_mandatory_fields(self, list_of_dict, *argv):
    #     for element in list_of_dict:
    #         for arg in argv:
    #             if not arg in element:
    #                 raise ATPDException(UserMessages.format_message(UserMessages.VALIDATOR_MISSING_KEY, element = arg))
    #             if not element[arg]:
    #                 raise ATPDException(UserMessages.format_message(UserMessages.VALIDATOR_EMPTY_VALUE, element = arg))
    #     return True

    def _validate_mandatory_fields_if_arg_specified(self, list_of_dict, deciding_arg_name, *argv):
        """
        Validate the mandatory fields are set and are not null/empty
        :param list_of_dict: (dict)
        :param deciding_arg_name: (String) The dictionary name to validate
        :param argv: The arguments to validate
        :return:
        """
        for element in list_of_dict:
            if element.startswith(deciding_arg_name):
                for arg in argv:
                    if not isinstance(list_of_dict[element], dict):
                        raise ATPDException(UserMessages.format_message(UserMessages.INCORRECT_ENTRY_SPECIFIED_FOR_ELEMENT, element = element))
                    if not arg in list_of_dict[element]:
                        element = element + "." + arg
                        raise ATPDException(UserMessages.format_message(UserMessages.VALIDATOR_MISSING_KEY, element = element))
                    if not list_of_dict[element][arg]:
                        element = element + "." + arg
                        raise ATPDException(UserMessages.format_message(UserMessages.VALIDATOR_EMPTY_VALUE, element = element))
        return True

    def _validate_for_dict_object(self,raw_data,property_to_validate):
        """
        Validate format is correct and expected keys are present
        :param raw_data: (dict)
        :param property_to_validate: (Str)
        :return:
        """
        if not property_to_validate in raw_data:
            raise ATPDException(UserMessages.format_message(UserMessages.VALIDATOR_MISSING_KEY, element = property_to_validate))
        if not isinstance(raw_data[property_to_validate], dict):
            raise ATPDException(UserMessages.format_message(UserMessages.INCORRECT_ENTRY_SPECIFIED_FOR_ELEMENT, element = property_to_validate))

    def validate_mandatory_fields(self,raw_data):
        """
        Validate all required sections of YAML sre set
        :param raw_data: (dict)
        :return:
        """
        # Validate all required sections of YAML are set
        self._validate_for_dict_object(raw_data,SetupConstants.FLEET_ADMIN_GROUPS_PROPERTY)
        self._validate_for_dict_object(raw_data,SetupConstants.DBA_GROUPS_PROPERTY)

        self._validate_mandatory_fields_if_arg_specified(raw_data[SetupConstants.FLEET_ADMIN_GROUPS_PROPERTY], SetupConstants.GROUP_PROPERTY, SetupConstants.GROUP_NAME_PROPERTY, SetupConstants.GROUP_DESCRIPTION_PROPERTY, SetupConstants.FLEET_COMPARTMENTS_PROPERTY)
        self._validate_mandatory_fields_if_arg_specified(raw_data[SetupConstants.DBA_GROUPS_PROPERTY], SetupConstants.GROUP_PROPERTY, SetupConstants.GROUP_NAME_PROPERTY, SetupConstants.GROUP_DESCRIPTION_PROPERTY,SetupConstants.DBA_COMPARTMENTS_PROPERTY,SetupConstants.FLEET_COMPARTMENTS_PROPERTY)
        if SetupConstants.POLICY_PROPERTY in raw_data:
            self._validate_mandatory_fields_if_arg_specified(raw_data[SetupConstants.POLICY_PROPERTY], SetupConstants.POLICY_PROPERTY, SetupConstants.POLICY_NAME_PROPERTY, SetupConstants.POLICY_DESCRIPTION_PROPERTY, SetupConstants.POLICY_STATEMENTS_PROPERTY)

        #validating user properties
        if SetupConstants.USERS_PROPERTY in raw_data:
            for key,value in raw_data[SetupConstants.USERS_PROPERTY].items():
                if isinstance(value,dict):
                    if SetupConstants.USER_NAME_PROPERTY in value and value[SetupConstants.USER_NAME_PROPERTY]:
                        if not SetupConstants.USER_DESCRIPTION_PROPERTY in value or not value[SetupConstants.USER_DESCRIPTION_PROPERTY]:
                            raise ATPDException(UserMessages.format_message(UserMessages.VALIDATOR_MISSING_KEY, element = key+"."+SetupConstants.USER_DESCRIPTION_PROPERTY))
                else:
                    raise ATPDException(UserMessages.format_message(UserMessages.INCORRECT_ENTRY_SPECIFIED_FOR_ELEMENT, element = key))

    def validate_oci_connection(self,setup_bean):
        """
        Validate OCI connection using provided credentials
        :param setup_bean: (SetupBean)
        :return:
        """
        #if object creation is fine, that means credentilas are correct
        a = setup_bean.get_oci_connection_data()
        if not a or not isinstance(a, dict):
            raise ATPDException(UserMessages.format_message(UserMessages.INCORRECT_ENTRY_SPECIFIED_FOR_ELEMENT, element = SetupConstants.OCI_CONNECTION_PROPERTY))
        OCIIdentityHandler(a)
        logging.info("OCI credentials are valid")

    def validate_compartments(self, setup_bean):
        """
        Validate all compartments are previously created in OCI
        :param setup_bean: (SetupBean)
        :return:
        """
        oci_connection=setup_bean.get_oci_connection_data()
        oci_identity = OCIIdentityHandler(oci_connection)
        # Validate Fleet compartments
        for group in setup_bean.get_access_setup_bean().get_fleet_admin_groups():
            compartments = group[SetupConstants.FLEET_COMPARTMENTS_PROPERTY]
            fleet_compartments=[]
            if isinstance(compartments, list):
                fleet_compartments = compartments
            else:
                fleet_compartments.extend(compartments.split(","))
            for compartment in fleet_compartments:
                if not oci_identity.get_compartment(compartment.strip()):
                    raise ATPDException(UserMessages.format_message(UserMessages.OCI_COMPARTMENT_DOES_NOT_EXIST, compartment_name = compartment.strip()))
        # Validate DBA compartments
        for group in setup_bean.get_access_setup_bean().get_dba_groups():
            compartments = group[SetupConstants.DBA_COMPARTMENTS_PROPERTY]
            dba_compartments=[]
            if isinstance(compartments, list):
                dba_compartments = compartments
            else:
                dba_compartments.extend(compartments.split(","))
            for compartment in dba_compartments:
                if not oci_identity.get_compartment(compartment.strip()):
                    raise ATPDException(UserMessages.format_message(UserMessages.OCI_COMPARTMENT_DOES_NOT_EXIST, compartment_name = compartment.strip()))
            compartments = group[SetupConstants.FLEET_COMPARTMENTS_PROPERTY]
            fleet_compartments=[]
            if isinstance(compartments, list):
                fleet_compartments = compartments
            else:
                fleet_compartments.extend(compartments.split(","))
            for compartment in fleet_compartments:
                if not oci_identity.get_compartment(compartment.strip()):
                    raise ATPDException(UserMessages.format_message(UserMessages.OCI_COMPARTMENT_DOES_NOT_EXIST, compartment_name = compartment.strip()))

