from oracle.install.cloud.atpd.access.resource.setup_constants import SetupConstants


class ModelLoader:
    """
    Splits the raw data into functional groups and sections
    """

    def _split_users(self, users_data, setup_bean):
        """
        Split the users
        :param users_data: (dict)
        :param setup_bean: (SetupBean)
        :return:
        """
        users=[]
        for key, value in users_data.items():
            if key.startswith(SetupConstants.USER_PROPERTY):
                users.append(users_data[key])
        setup_bean.get_access_setup_bean().set_users(users)

    def _slit_fleet_groups(self, fleet_groups_data, setup_bean):
        """
        Split the fleet groups
        :param fleet_groups_data: (dict)
        :param setup_bean: (SetupBean)
        :return:
        """
        groups=[]
        for key, value in fleet_groups_data.items():
            if key.startswith(SetupConstants.GROUP_PROPERTY):
                groups.append(fleet_groups_data[key])
        setup_bean.get_access_setup_bean().set_fleet_groups(groups)

    def _slit_dba_groups(self, dba_groups_data, setup_bean):
        """
        Split the dba groups
        :param dba_groups_data: (dict)
        :param setup_bean: (SetupBean)
        :return:
        """
        groups=[]
        for key, value in dba_groups_data.items():
            if key.startswith(SetupConstants.GROUP_PROPERTY):
                groups.append(dba_groups_data[key])
        setup_bean.get_access_setup_bean().set_dba_groups(groups)

    def _split_policies(self, policies_data, setup_bean):
        """
        Split the policies
        :param policies_data: (dict)
        :param setup_bean: (SetupBean)
        :return:
        """
        policies=[]
        for key, value in policies_data.items():
            if key.startswith(SetupConstants.POLICY_PROPERTY):
                policies.append(policies_data[key])
        setup_bean.get_access_setup_bean().set_policies(policies)

    def load_models(self,processed_raw_data,setup_bean):
        """
        Splits the raw data into functional groups and sections
        :param processed_raw_data: (dict)
        :param setup_bean: (SetupBean)
        :return:
        """
        if SetupConstants.USERS_PROPERTY in processed_raw_data:
            self._split_users(processed_raw_data[SetupConstants.USERS_PROPERTY],setup_bean)
        if SetupConstants.FLEET_ADMIN_GROUPS_PROPERTY in processed_raw_data:
            self._slit_fleet_groups(processed_raw_data[SetupConstants.FLEET_ADMIN_GROUPS_PROPERTY], setup_bean)
        if SetupConstants.DBA_GROUPS_PROPERTY in processed_raw_data:
            self._slit_dba_groups(processed_raw_data[SetupConstants.DBA_GROUPS_PROPERTY], setup_bean)
        if SetupConstants.POLICIES_PROPERTY in processed_raw_data:
            self._split_policies(processed_raw_data[SetupConstants.POLICIES_PROPERTY],setup_bean)