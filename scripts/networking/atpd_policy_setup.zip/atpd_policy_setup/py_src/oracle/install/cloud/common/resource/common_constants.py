
class CommonConstants:
    """
    Defines custom constants
    """
    # OCI connection constants
    OCI_USER_PROPERTY = "user"
    OCI_FINGERPRINT_PROPERTY = "fingerprint"
    OCI_KEY_FILE_PROPERTY = "key_file"
    OCI_TENANCY_PROPERTY = "tenancy"
    OCI_REGION_PROPERTY = "region"
    CUSTOM_CERT_LOCATION_PROPERTY="custom_cert_location"
    DOMAIN_NAME_OVERRIDE_PROPERTY="domain_name_override"
    R1_CERT_LOCATION_PROPERTY="R1_CERT_LOCATION"
    REQUESTS_CA_BUNDLE_PROPERTY="REQUESTS_CA_BUNDLE"

    # Status codes
    SUCCESS_STATUS_CODE = 200