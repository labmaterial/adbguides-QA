import re

from oracle.install.cloud.common.resource.atpd_exception import ATPDException
from oracle.install.cloud.common.resource.user_messages import UserMessages


class VariableHandler:
    """
    Handles the variables substitution in YAML file
    """

    def validate(self,raw_data):
        """
        Validate variables defined in YAML file
        :param raw_data: (dict)
        :return:
        """
        composed_elements = self._get_composed_elements(raw_data)
        self._validate_variables(composed_elements,raw_data)

    def process_variables(self,raw_data):
        """
        Get the values to substitute and replace variables
        :param raw_data: (dict)
        :return: (dict) The processed raw data
        """
        composed_elements = self._get_composed_elements(raw_data)
        processed_data=self._process_variables(composed_elements,raw_data)
        return processed_data

    def _process_variables(self, composed_elements,raw_data):
        """
        Replace the variables with its respective values
        :param composed_elements: (dict) values to substitute
        :param raw_data: (dict) data to process
        :return: (dict) The processed data
        """
        if isinstance(raw_data,dict):
            processed_dict={}
            for key, value in raw_data.items():
                processed_dict[key]=self._process_variables(composed_elements,value)
            return processed_dict
        elif isinstance(raw_data, list):
            value_list=[]
            for element in raw_data:
                processed_value=self._process_variables(composed_elements, element)
                value_list.append(processed_value)
            return value_list
        else:
            # Replace variable
            processed_value=self._replace_variable_value(raw_data,composed_elements)
            return processed_value

    def _get_composed_elements(self, data, prefix=''):
        """
        Get the values to substitute
        :param data: (dict)
        :param prefix: (str)
        :return: (dict)
        """
        composed_elements = {}
        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, dict):
                    composed_elements.update(self._get_composed_elements(value, prefix=prefix + key + "."))
                elif not isinstance(data, list):
                    composed_elements["{" + prefix + key + "}"] = value
        return composed_elements

    def _replace_variable_value(self,value,composed_elements):
        """
        Replace the variables with its corresponding values
        :param value: (str) Key to search for
        :param composed_elements: (list) Values  to substitute with
        :return: The substituted value
        """
        if value:
            all_patterns = re.findall(r'(\{[0-9A-Za-z._-]+\})', value)
            # Verify all patterns in current value are previously defined
            if not all(pattern in composed_elements for pattern in all_patterns):
                error_msg = UserMessages.format_message(UserMessages.VARIABLE_PATTERN_NOT_DEFINED, patterns =','.join(all_patterns))
                raise ATPDException(error_msg)
            # Verify patterns do not have null values
            if not all(composed_elements[pattern] for pattern in all_patterns):
                error_msg = UserMessages.format_message(UserMessages.VARIABLES_WITH_NULL_VALUES, patterns =','.join(all_patterns))
                raise ATPDException(error_msg)
            replaced_value = re.sub(r'(\{[0-9A-Za-z._-]+\})', lambda x: composed_elements.get(x.group()), value)
            return replaced_value
        return value

    def _validate_variables(self, composed_elements,raw_data):
        """
        Validate the variables to substitute
        :param composed_elements: (list)
        :param raw_data: (dict)
        :return:
        """
        if isinstance(raw_data,dict):
            for key, value in raw_data.items():
                self._validate_variables(composed_elements,value)
        elif isinstance(raw_data, list):
            for element in raw_data:
                self._validate_variables(composed_elements,element)
        else:
            self._replace_variable_value(raw_data,composed_elements)
