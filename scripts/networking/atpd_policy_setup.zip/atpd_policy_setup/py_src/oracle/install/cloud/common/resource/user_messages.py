
class UserMessages:
    """
    Defines the messages presented to user
    """
    @staticmethod
    def format_message(error_message, **kwargs):
        """
        Formats the messages
        :param error_message: (str)
        :param kwargs: Arguments to substitute
        :return: (str) formated message
        """
        if len(kwargs) > 0:
            return error_message.format(**kwargs)
        return error_message

    # yaml_validator.py
    VARIABLE_PATTERN_NOT_DEFINED = "Invalid input data: One of the following variables are not defined: {patterns}"
    VARIABLES_WITH_NULL_VALUES = "Invalid input: One of the following variables have null values: {patterns}"
    VALIDATOR_EMPTY_VALUE = "Invalid input: The key '{element}' has an empty value"
    VALIDATOR_MISSING_KEY = "Invalid input: One of the fields has the following missing element: '{element}'"
    INCORRECT_ENTRY_SPECIFIED_FOR_ELEMENT = "Invalid input: The value specified for '{element}' is not syntactially correct. Value should be a dictionary object."
    YAML_VALIDATOR_MALFORMED_YAML = "Not valid YAML file"
    YAML_FILE_NOT_SPECIFIED="Yaml file is not specified"
    YAML_FILE_DOESNOT_EXISTS="Specified yaml file '{yaml_file} doesn't exists"
    YAML_FILE_CANNOT_BE_READ="Unable to read the specified yaml file '{yaml_file}'"
    UNABLE_TO_FIND_FLEET_POLICY_TO_ADD_DBA_ACCESS_STATEMENTS= "Unable to find fleet policy for fleet compartment '{fleet_compartment}' to add dba access rule for dba group '{dba_group}'"
    OCI_COMPARTMENT_DOES_NOT_EXIST = "Compartment '{compartment_name}' does not exist in OCI"
    NO_INPUT_DATA_ERR="No data found in the specified input file"

    # oci_components_handler.py
    OCI_CONNECTION_ERROR = "The required information to complete the OCI authentication was not provided or was incorrect"
    OCI_CONNECTION_DATA_ERROR = "OCI connection failed while validating credentials: {error}"
    OCI_AUTHENTICATION_ERROR = "OCI authentication failed: {error}"
    OCI_NEW_COMPONENT_CREATED = "New {component} {component_name} was created!"
    OCI_COMPONENT_ALREADY_EXIST = "{component} with name {component_name} already exist"
    OCI_ADDED_TO_GROUP = "User {user_name} was added to group {group_name}!"
    OCI_USER_DOES_NOT_EXISTS = "User with name {user_name} does not exist"
    OCI_USER_BELONGS_TO_GROUP = "User {user_name} already belongs to group {group_name}"
    OCI_CONNECTION_FAILED = "Something went wrong trying to connect to OCI. Check the log file for more details..."
    OCI_CREATING_COMPONENT = "Creating {component} {component_name}"
    OCI_ADDING_USER_TO_GROUP = "Adding user {user_name} to group {group_name}"

    #admin_policy.py
    ADMIN_COMPARTMENT_DOESNT_EXIST = "Compartment {compartment} does not exist in current tenancy"
    ADMIN_USER_CREATION_FAILED = "User {username} creation failed"
    ADMIN_GROUP_CREATION_FAILED = "Group {group_name} creation failed"
    ADMIN_ADD_USER_TO_GROUP_FAILED = "Adding user {username} to group {group_name} failed"
    ADMIN_POLICY_CREATION_FAILED = "Policy {policy_name} creation failed"
    ADMIN_COMPARTMENT_FOUND = "Compartment {compartment} was found in tenancy!"
    ADMIN_SUCCESS = "SUCCESS"
    ADMIN_FAILED = "FAILED"

    #Progress messages
    VALIDATING_YAML_FILE_STATUS_MSG="Validating yaml file"
    LOADING_YAML_FILE_STATUS_MSG="Loading input yaml file"
    PERFORMING_VALIDATIONS_STATUS_MSG= "Performing validations of input data"
    PROCESSING_VAIRABLES_STATUS_MSG="Processing variables"
    LOADING_MODELS_STATUS_MSG="Loading model classes"
    GENERATING_POLICIES_STATUS_MSG="Generating policies"
    GENERATING_YAML_FILE_STATUS_MSG="Generating yaml file"
    CREATING_USERS_STATUS_MSG="Creating users"
    CREATING_USER_STATUS_MSG="Creating user '{user_name}'"
    USER_EXIST_STATUS_MSG="User '{user_name}' already created in the tenancy"
    CREATING_GROUP_STATUS_MSG="Creating group '{group_name}'"
    GROUP_EXIST_STATUS_MSG="Group '{group_name}' already created in the tenancy"
    CREATING_POLICY_STATUS_MSG="Creating policy '{policy_name}'"
    POLICY_EXIST_STATUS_MSG="Policy '{policy_name}' already created in the tenancy"
    ADDING_POLICY_STATEMENTS="Adding policy statements to the policy '{policy_name}'"
    ADDING_USER_TO_GROUP="Adding user '{user_name}' to group '{group_name}'"
    SETUP_COMPLETED="Setup completed"

