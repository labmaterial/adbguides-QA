import os

class SetupConstants:
    """
    Defines project constants
    """
    # Arguments
    TEMPLATE_ARG="yaml_template"
    GENERATE_POLICIES_ARG="generate_policies"
    TIMESTAMP_ARG="timestamp"
    # YAML properties
    USERS_PROPERTY = "users"
    USER_PROPERTY="user"
    USER_NAME_PROPERTY = "name"
    USER_DESCRIPTION_PROPERTY = "description"
    USER_EMAIL_PROPERTY = "email"
    FLEET_ADMIN_GROUPS_PROPERTY = "fleet_admin_groups"
    DBA_GROUPS_PROPERTY = "dba_groups"
    GROUP_PROPERTY="group"
    GROUP_NAME_PROPERTY = "name"
    GROUP_DESCRIPTION_PROPERTY = "description"
    FLEET_COMPARTMENTS_PROPERTY="fleet_compartments"
    DBA_COMPARTMENTS_PROPERTY="dba_compartments"
    GROUP_MEMBERS_PROPERTY = "members"
    POLICIES_PROPERTY="policies"
    POLICY_PROPERTY = "policy"
    POLICY_NAME_PROPERTY = "policy_name"
    POLICY_DESCRIPTION_PROPERTY = "description"
    POLICY_STATEMENTS_PROPERTY = "policy_statements"
    OCI_CONNECTION_PROPERTY = "oci_connection"
    # Project's root directory
    PROJECT_HOME = os.environ.get('PROJECT_HOME')
    # logs directory
    LOGS_DIRECTORY = PROJECT_HOME + "/logs"
    LOG_FILE_PATH=LOGS_DIRECTORY
    # templates directory
    TEMPLATES_DIRECTORY = PROJECT_HOME + "/yaml_templates"
    # Timestamp
    SESSION_TIME_STAMP=""
    # Project files
    APPLICATION_NAME="atpd-policy-setup"
    DEFAULT_YAML_TEMPLATE_NAME="atpd_access_config.yaml"
    GENERATED_YAML_FILE_NAME="generated_atpd_access_config"
    OCI_CONFIG_FILE="~/.oci/config"
