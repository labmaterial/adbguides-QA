import argparse

from oracle.install.cloud.atpd.access.driver.setup_driver import SetupDriver
from oracle.install.cloud.atpd.access.resource.setup_constants import SetupConstants
from oracle.install.cloud.common.util.logging_handler import LoggingHandler
from oracle.install.cloud.common.resource.progress_reporter import ProgressReporter

class Setup:
    """
    Entry point class
    """

    def startup(self):
        """
        Startup method which act as entry point for setup.
        :return:
        """
        arguments=self.process_args()
        SetupConstants.SESSION_TIME_STAMP = arguments.timestamp
        self.configure_logging()
        SetupDriver().startup(arguments)

    def configure_logging(self):
        """
        Configure logging
        :return:
        """
        SetupConstants.LOG_FILE_PATH=SetupConstants.LOGS_DIRECTORY+"/"+SetupConstants.APPLICATION_NAME+"_"+SetupConstants.SESSION_TIME_STAMP+".log"
        log_handler = LoggingHandler(SetupConstants.LOG_FILE_PATH)
        log_handler.create_log()

    def process_args(self):
        """
        To process the arguments
        :return:
        """
        parser = argparse.ArgumentParser()
        parser.add_argument('--'+SetupConstants.TEMPLATE_ARG, help='The YAML file', required=True)
        parser.add_argument('--'+SetupConstants.TIMESTAMP_ARG, help=argparse.SUPPRESS, required=True)
        parser.add_argument('--'+SetupConstants.GENERATE_POLICIES_ARG, help='To generate yaml file with policies', required=False, action='store', nargs='?', const=True)
        arguments = parser.parse_args()
        return arguments

def __main__():
    """
    Main entry point
    :return:
    """
    try:
        Setup().startup()
    except Exception as err:
        ProgressReporter().exception(err,SetupConstants.LOG_FILE_PATH)
        exit(1)


__main__()
