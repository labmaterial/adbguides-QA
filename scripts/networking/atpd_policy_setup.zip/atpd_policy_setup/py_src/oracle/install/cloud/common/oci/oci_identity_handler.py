import logging

import oci

from oracle.install.cloud.common.resource.atpd_exception import ATPDException
from oracle.install.cloud.common.resource.common_constants import CommonConstants
from oracle.install.cloud.common.resource.user_messages import UserMessages


class OCIIdentityHandler:
    """
    Handles OCI interaction
    """

    def __init__(self, connection_data):
        """
        Constructor
        :param connection_data: (dict)
        """
        self._conn_data = connection_data
        self._identity_client = None
        if self._conn_data:
            try:
                oci.config.validate_config(self._conn_data)
                self._identity_client = oci.identity.IdentityClient(self._conn_data, retry_strategy=oci.retry.DEFAULT_RETRY_STRATEGY)
                # Try connection
                user=self._identity_client.get_user(self._conn_data[CommonConstants.OCI_USER_PROPERTY]).data
            except oci.exceptions.InvalidConfig as err:
                logging.error(err,exc_info=True)
                raise ATPDException(UserMessages.format_message(UserMessages.OCI_CONNECTION_DATA_ERROR, error = err))
            except oci.exceptions.ServiceError as err:
                logging.error(err,exc_info=True)
                raise ATPDException(UserMessages.format_message(UserMessages.OCI_CONNECTION_ERROR, error = err))
            except Exception as err:
                logging.error(err,exc_info=True)
                raise ATPDException(UserMessages.format_message(UserMessages.OCI_AUTHENTICATION_ERROR, error = err))

    def _get_component(self, elements_list, component_name):
        """
        Generic method to look for an specific OCI component
        :param elements_list: (function)
        :param component_name: (String)
        :return:
        """
        if self._identity_client and component_name:
            list_response = oci.pagination.list_call_get_all_results(elements_list, self._conn_data[CommonConstants.OCI_TENANCY_PROPERTY])
            if list_response.status == CommonConstants.SUCCESS_STATUS_CODE:
                for component in list_response.data:
                    if component_name == component.name:
                        return component
        return None

    def get_user(self, user_name):
        """
        Look if user is in OCI
        :param user_name: (str)
        :return: (dict) user data or None
        """
        return self._get_component(elements_list = self._identity_client.list_users, component_name = user_name)

    def get_compartment(self, compartment_name):
        """
        Look if compartment is in OCI
        :param compartment_name: (str)
        :return: (dict) compartmen data or None
        """
        return self._get_component(elements_list = self._identity_client.list_compartments, component_name = compartment_name)

    def get_group(self, group_name):
        """
        Look if group is in OCI
        :param group_name: (str)
        :return: (dict) group data or None
        """
        return self._get_component(elements_list = self._identity_client.list_groups, component_name = group_name)

    def get_policy(self, policy_name):
        """
        Look if policy is in OCI
        :param policy_name: (str)
        :return: (dict) policy data or None
        """
        return self._get_component(elements_list = self._identity_client.list_policies, component_name = policy_name)

    def does_user_belongs_to_group(self, user_name, group_name):
        """
        Look if user belongs to group
        :param user_name: (str)
        :param group_name: (str)
        :return: (boolean)
        """
        if self._identity_client and user_name and group_name:
            user = self.get_user(user_name)
            group = self.get_group(group_name)
            if user and group:
                membership = self._identity_client.list_user_group_memberships(compartment_id = self._conn_data[CommonConstants.OCI_TENANCY_PROPERTY], user_id = user.id, group_id = group.id)
                return len(membership.data) >= 1

    def create_user(self, user_name, description, email = None):
        """
        Create a new user or return existing one
        :param user_name: (str)
        :param description: (str)
        :param email: (str)
        :return: (dict) user data
        """
        user = None
        if user_name and description:
            logging.info(UserMessages.format_message(UserMessages.OCI_CREATING_COMPONENT, component = 'user', component_name = user_name))
            user = self.get_user(user_name)
            if not user:
                response = self._identity_client.create_user(oci.identity.models.CreateUserDetails(compartment_id = self._conn_data[CommonConstants.OCI_TENANCY_PROPERTY], name = user_name, description = description, email = email), retry_strategy = oci.retry.DEFAULT_RETRY_STRATEGY)
                if response.status == CommonConstants.SUCCESS_STATUS_CODE:
                    user = response.data
                    logging.info(UserMessages.format_message(UserMessages.OCI_NEW_COMPONENT_CREATED, component = 'user', component_name = user_name))
                else:
                    return None
            else:
                logging.info(UserMessages.format_message(UserMessages.OCI_COMPONENT_ALREADY_EXIST, component = 'User', component_name = user_name))
        return user

    def create_group(self, group_name, description):
        """
        Create a new group or return existing one
        :param group_name: (str)
        :param description: (str)
        :return: (dict) group data
        """
        group = None
        if group_name and description:
            logging.info(UserMessages.format_message(UserMessages.OCI_CREATING_COMPONENT, component='group', component_name=group_name))
            group = self.get_group(group_name)
            if not group:
                response = self._identity_client.create_group(oci.identity.models.CreateGroupDetails(compartment_id = self._conn_data[CommonConstants.OCI_TENANCY_PROPERTY], name = group_name, description = description),retry_strategy = oci.retry.DEFAULT_RETRY_STRATEGY)
                if response.status == CommonConstants.SUCCESS_STATUS_CODE:
                    group = response.data
                    logging.info(UserMessages.format_message(UserMessages.OCI_NEW_COMPONENT_CREATED, component = 'group', component_name = group_name))
                else:
                    return None
            else:
                logging.info(UserMessages.format_message(UserMessages.OCI_COMPONENT_ALREADY_EXIST, component = 'Group', component_name = group_name))
        return group

    def add_user_to_group(self, user_name, group_name):
        """
        Add an existing user to an existing group
        :param user_name: (str)
        :param group_name: (str)
        :return: (dict) Membership data
        """
        result = None
        if user_name and group_name:
            logging.info(UserMessages.format_message(UserMessages.OCI_ADDING_USER_TO_GROUP, user_name=user_name, group_name=group_name))
            user_in_group = self.does_user_belongs_to_group(user_name = user_name, group_name = group_name)
            if not user_in_group:
                user = self.get_user(user_name)
                group = self.get_group(group_name)
                if user and group:
                    response = self._identity_client.add_user_to_group(oci.identity.models.AddUserToGroupDetails(user_id = user.id, group_id = group.id))
                    if response.status == CommonConstants.SUCCESS_STATUS_CODE:
                        result = response.data

                        logging.info(UserMessages.format_message(UserMessages.OCI_ADDED_TO_GROUP, user_name = user_name, group_name = group_name))
                    else:
                        return None
                else:
                    logging.info(UserMessages.format_message(UserMessages.OCI_USER_DOES_NOT_EXISTS, user_name = user_name))
            else:
                logging.info(UserMessages.format_message(UserMessages.OCI_USER_BELONGS_TO_GROUP, user_name = user_name, group_name = group_name))
                return user_in_group
        return result

    def create_policy(self, policy_name, description, statements):
        """
        Create a new policy or return existing one
        :param policy_name: (str)
        :param description: (str)
        :param statements: (list)
        :return: (dict) policy data
        """
        policy = None
        if policy_name and description and isinstance(statements, list):
            logging.info(UserMessages.format_message(UserMessages.OCI_CREATING_COMPONENT, component='policy', component_name=policy_name))
            policy = self.get_policy(policy_name)
            if not policy:
                response= self._identity_client.create_policy(oci.identity.models.CreatePolicyDetails(compartment_id = self._conn_data[CommonConstants.OCI_TENANCY_PROPERTY], name = policy_name, description = description ,statements = statements), retry_strategy = oci.retry.DEFAULT_RETRY_STRATEGY)
                if response.status == CommonConstants.SUCCESS_STATUS_CODE:
                    policy = response.data
                    logging.info(UserMessages.format_message(UserMessages.OCI_NEW_COMPONENT_CREATED, component = 'policy', component_name = policy_name))
                else:
                    return None
            else:
                logging.info(UserMessages.format_message(UserMessages.OCI_COMPONENT_ALREADY_EXIST, component = 'Policy', component_name = policy_name))
                logging.info("Updating policy statements")
                response= self._identity_client.update_policy(policy.id,oci.identity.models.UpdatePolicyDetails(description=description,statements=statements),retry_strategy=oci.retry.DEFAULT_RETRY_STRATEGY)
                if response.status == CommonConstants.SUCCESS_STATUS_CODE:
                    return response.data
                else:
                    return None
        return policy