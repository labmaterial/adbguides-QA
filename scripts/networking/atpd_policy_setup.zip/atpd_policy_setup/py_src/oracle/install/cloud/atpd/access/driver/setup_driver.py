import logging
import os

from oracle.install.cloud.atpd.access.driver.model_loader import ModelLoader
from oracle.install.cloud.atpd.access.driver.oci_connection_loader import OCIConnectionLoader
from oracle.install.cloud.atpd.access.driver.policy_generator import PolicyGenerator
from oracle.install.cloud.atpd.access.driver.yaml_generator import YAMLGenerator
from oracle.install.cloud.atpd.access.models.setup_bean import SetupBean
from oracle.install.cloud.atpd.access.resource.setup_constants import SetupConstants
from oracle.install.cloud.atpd.access.validator.setup_validator import SetupValidator
from oracle.install.cloud.common.oci.oci_identity_handler import OCIIdentityHandler
from oracle.install.cloud.common.resource.atpd_exception import ATPDException
from oracle.install.cloud.common.resource.progress_reporter import ProgressReporter
from oracle.install.cloud.common.resource.user_messages import UserMessages
from oracle.install.cloud.common.variable.variable_handler import VariableHandler
from oracle.install.cloud.common.yaml.yaml_loader import YAMLLoader


class SetupDriver:
    """
    Defines the main flow
    """

    def __init__(self):
        self._setup_bean=SetupBean()
        self._progress_reporter=ProgressReporter()
        self._oci_handler=None

    def startup(self,arguments):
        """
        Main flow of the setup
        :param arguments: (dict)
        :return:
        """
        if arguments:
            yaml_file = arguments.yaml_template
            # Load YAML file
            self._progress_reporter.status(UserMessages.VALIDATING_YAML_FILE_STATUS_MSG)
            self.load_yaml_file(yaml_file)
            # Validate the file
            self._progress_reporter.status(UserMessages.PERFORMING_VALIDATIONS_STATUS_MSG)
            SetupValidator().validate(self._setup_bean.get_raw_data())
            # Substitute the values in variables
            self._progress_reporter.status(UserMessages.PROCESSING_VAIRABLES_STATUS_MSG)
            self.process_variables()
            # Load the setup bean
            self._progress_reporter.status(UserMessages.LOADING_MODELS_STATUS_MSG)
            self.load_setup_bean()
            # Load and validate OCI credentials
            # Validate compartments
            if not arguments.generate_policies:
                self.load_oci_credentials()
                SetupValidator().validate_oci_connection(self._setup_bean)
                SetupValidator().validate_compartments(self._setup_bean)
            # Generate policies
            self._progress_reporter.status(UserMessages.GENERATING_POLICIES_STATUS_MSG)
            self.generate_policies()
            self._progress_reporter.status(UserMessages.GENERATING_YAML_FILE_STATUS_MSG)
            self.generate_yaml_file()
            if not arguments.generate_policies:
                self._oci_handler=OCIIdentityHandler(self._setup_bean.get_oci_connection_data())
                self.setup()
            self._progress_reporter.status(UserMessages.SETUP_COMPLETED)

    def load_yaml_file(self,yaml_file):
        """
        Load yaml and save its content
        :param yaml_file: (str) The file path
        :return:
        """
        if yaml_file:
            if os.path.exists(yaml_file):
                raw_data=YAMLLoader().load_yaml(yaml_file)
                self._setup_bean.set_raw_data(raw_data)
            else:
                raise ATPDException(UserMessages.format_message(UserMessages.YAML_FILE_DOESNOT_EXISTS,yaml_file=yaml_file))
        else:
            raise ATPDException(UserMessages.format_message(UserMessages.YAML_FILE_NOT_SPECIFIED))


    def process_variables(self):
        """
        Substitute the values in variables
        :return:
        """
        raw_data=self._setup_bean.get_raw_data()
        if raw_data:
            processed_data=VariableHandler().process_variables(raw_data)
            if processed_data:
                self._setup_bean.set_processed_data(processed_data)
            else:
                logging.warning("Processed raw data is empty")
        else:
            logging.warning("Raw data is empty. So skiping processing")


    def load_setup_bean(self):
        """
        Splits the raw data into functional groups and sections
        :return:
        """
        proccessed_raw_data=self._setup_bean.get_processed_data()
        if proccessed_raw_data:
            ModelLoader().load_models(proccessed_raw_data,self._setup_bean)
        else:
            logging.warning("Processed raw data is emtpy. So not loading setup bean")

    def load_oci_credentials(self):
        """
        Load the oci credentials
        :return:
        """
        proccessed_raw_data = self._setup_bean.get_processed_data()
        if proccessed_raw_data:
            connection_data = OCIConnectionLoader().load_oci_connection_data(proccessed_raw_data)
            if not connection_data:
                logging.error("Connection data was not found")
            else:
                self._setup_bean.set_oci_connection_data(connection_data)
        else:
            logging.warning("Processed raw data is emtpy. So not loading oci connection data")

    def generate_policies(self):
        """
        Generate the policies
        :return:
        """
        access_setup_bean=self._setup_bean.get_access_setup_bean()
        if not access_setup_bean :
            logging.warning("Access setup bean is empty. So not generating policies")
            return
        if access_setup_bean.get_policies():
            logging.info("Policies are already present in Access setup bean. So skipping policy generation")
            return
        PolicyGenerator().generate_policies(access_setup_bean)

    def generate_yaml_file(self):
        """
        Generate the YAML file
        :return:
        """
        yaml_generator = YAMLGenerator(self._setup_bean)
        yaml_generator.generate_yaml_file()

    def setup(self):
        """
        Generate all components in the tenancy
        :return:
        """
        access_setup_bean=self._setup_bean.get_access_setup_bean()
        if access_setup_bean:
            if access_setup_bean.get_users():
                self.setup_users(access_setup_bean.get_users())
            if access_setup_bean.get_fleet_admin_groups():
                self.setup_groups(access_setup_bean.get_fleet_admin_groups())
            if access_setup_bean.get_dba_groups():
                self.setup_groups(access_setup_bean.get_dba_groups())
            if access_setup_bean.get_policies():
                self.setup_policies(access_setup_bean.get_policies())

    def setup_users(self,users):
        """
        Create the users in the tenancy
        :param users: (list)
        :return:
        """
        if users:
            oci_bean=self._setup_bean.get_oci_bean()
            for user in users:
                if SetupConstants.USER_NAME_PROPERTY in user and user[SetupConstants.USER_NAME_PROPERTY]:
                    self._progress_reporter.status(UserMessages.format_message(UserMessages.CREATING_USER_STATUS_MSG, user_name=user[SetupConstants.USER_NAME_PROPERTY]))
                    new_user = self._oci_handler.create_user(user_name = user[SetupConstants.USER_NAME_PROPERTY], description = user[SetupConstants.USER_DESCRIPTION_PROPERTY], email = (user[SetupConstants.USER_EMAIL_PROPERTY] if SetupConstants.USER_EMAIL_PROPERTY in user else "" ))
                    if not new_user:
                        message=UserMessages.format_message(UserMessages.ADMIN_USER_CREATION_FAILED, username = user[SetupConstants.USER_NAME_PROPERTY])
                        raise ATPDException(message)
                    else:
                        oci_bean.get_users().append(new_user)

    def setup_groups(self,groups):
        """
        Create the groups in the tenancy
        :param groups: (list)
        :return:
        """
        if groups:
            oci_bean=self._setup_bean.get_oci_bean()
            for group in groups:
                self._progress_reporter.status(UserMessages.format_message(UserMessages.CREATING_GROUP_STATUS_MSG,group_name=group[SetupConstants.GROUP_NAME_PROPERTY]))
                new_group = self._oci_handler.create_group(group_name = group[SetupConstants.GROUP_NAME_PROPERTY], description = group[SetupConstants.GROUP_DESCRIPTION_PROPERTY])
                if not new_group:
                    message=UserMessages.format_message(UserMessages.ADMIN_GROUP_CREATION_FAILED, group_name = group[SetupConstants.GROUP_NAME_PROPERTY])
                    raise ATPDException(message)
                else:
                    oci_bean.get_groups().append(new_group)
                if SetupConstants.GROUP_MEMBERS_PROPERTY in group and group[SetupConstants.GROUP_MEMBERS_PROPERTY]:
                    users = group[SetupConstants.GROUP_MEMBERS_PROPERTY]
                    members_list=[]
                    if isinstance(users, list):
                        members_list=users
                    else:
                        members_list.append(users)
                    # Add users to group
                    for user in members_list:
                        self._progress_reporter.status(UserMessages.format_message(UserMessages.ADDING_USER_TO_GROUP, user_name=user, group_name = group[SetupConstants.GROUP_NAME_PROPERTY]))
                        success = self._oci_handler.add_user_to_group(user_name = user, group_name = group[SetupConstants.GROUP_NAME_PROPERTY])
                        if not success:
                            message=UserMessages.format_message(UserMessages.ADMIN_ADD_USER_TO_GROUP_FAILED, username = user, group_name = group[SetupConstants.GROUP_NAME_PROPERTY])
                            raise ATPDException(message)

    def setup_policies(self,policies):
        """
        Create the policies in the tenancy
        :param policies: (list)
        :return:
        """
        oci_bean=self._setup_bean.get_oci_bean()
        for policy in policies:
            self._progress_reporter.status(UserMessages.format_message(UserMessages.CREATING_POLICY_STATUS_MSG,policy_name = policy[SetupConstants.POLICY_NAME_PROPERTY]))
            new_policy = self._oci_handler.create_policy(policy_name = policy[SetupConstants.POLICY_NAME_PROPERTY], description = policy[SetupConstants.POLICY_DESCRIPTION_PROPERTY], statements = policy[SetupConstants.POLICY_STATEMENTS_PROPERTY])
            if not new_policy:
                message=UserMessages.format_message(UserMessages.ADMIN_POLICY_CREATION_FAILED, policy_name = policy[SetupConstants.POLICY_NAME_PROPERTY])
                raise ATPDException(message)
            else:
                oci_bean.get_policies().append(new_policy)




