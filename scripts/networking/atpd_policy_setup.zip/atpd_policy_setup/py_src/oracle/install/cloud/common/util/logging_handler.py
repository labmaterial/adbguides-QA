import logging
import os


class LoggingHandler():
    """
    Formats the log messages
    """

    def __init__(self, log_path):
        """
        Constructor
        :param log_path: (str) The log path
        """
        self.__log_path = log_path

    def create_log(self):
        """
        Defines the messages format and file where the logs will be printed
        :return:
        """
        # Create log file
        logger = logging.getLogger('')
        if not os.path.exists(os.path.dirname(self.__log_path)):
            os.makedirs(os.path.dirname(self.__log_path))
        # Append mode
        job_logger = logging.FileHandler(self.__log_path, mode='a')
        # Define the output format
        job_logger.setLevel(logging.INFO)
        formatter = logging.Formatter('[%(asctime)s - Thread %(thread)d %(module)s.%(funcName)s line %(lineno)d] %(levelname)s - %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')
        job_logger.setFormatter(formatter)
        logger.addHandler(job_logger)
        logger.setLevel(logging.DEBUG)

    def get_log_location(self):
        """
        Get the location of log file
        :return: (str) Log file path
        """
        return self.__log_path