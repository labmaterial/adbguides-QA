import logging


class ProgressReporter:
    """
    Handles messages logging
    """

    def status(self,message,indentation_level=0):
        """
        Log info to logging file and console
        :param message:
        :param indentation_level:
        :return:
        """
        logging.info(message)
        print(message)

    def exception(self, message,log_file):
        """
        Log exception to logging file and console
        :param message:
        :param log_file:
        :return:
        """
        logging.exception(message)
        print("Error - " + str(message))
        print("Log file for this session: "+log_file)