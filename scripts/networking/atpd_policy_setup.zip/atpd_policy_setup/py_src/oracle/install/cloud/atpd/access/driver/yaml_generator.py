import copy
import logging

import yaml
from oracle.install.cloud.atpd.access.resource.setup_constants import SetupConstants

class YAMLGenerator:
    """
    Generates and saves YAML file
    """

    def __init__(self, setup_bean):
        """
        Constructor
        :param setup_bean: (SetupBean)
        """
        self._setup_bean = setup_bean
        self._yaml_representation_obj = None

    def generate_yaml_file(self):
        """
        Generates and saves the YAML file
        :return:
        """
        self._generate_yaml_object()
        self.save_yaml_file()

    def _generate_yaml_object(self):
        """
        Generate the YAML object to save
        :return:
        """
        if self._setup_bean.get_processed_data():
            processed_data = copy.deepcopy(self._setup_bean.get_processed_data())
            processed_data[SetupConstants.POLICIES_PROPERTY] = {}
            policies = self._setup_bean.get_access_setup_bean().get_policies()
            policy_number = 1
            for policy in policies:
                processed_data[SetupConstants.POLICIES_PROPERTY][
                    SetupConstants.POLICY_PROPERTY + str(policy_number)] = policy
                policy_number += 1
            #Remove OCI credentials
            for key, value in processed_data[SetupConstants.OCI_CONNECTION_PROPERTY].items():
                processed_data[SetupConstants.OCI_CONNECTION_PROPERTY][key] = ""
            self._yaml_representation_obj = processed_data
        else:
            logging.error("Data to generate yaml file is null or empty")

    def save_yaml_file(self):
        """
        Save the YAML file
        :return:
        """
        if self._yaml_representation_obj:
            yaml_file = SetupConstants.TEMPLATES_DIRECTORY + "/" + SetupConstants.GENERATED_YAML_FILE_NAME + "_" + SetupConstants.SESSION_TIME_STAMP + ".yaml"
            with open(yaml_file, 'w') as file:
                yaml.dump(self._yaml_representation_obj, file)
