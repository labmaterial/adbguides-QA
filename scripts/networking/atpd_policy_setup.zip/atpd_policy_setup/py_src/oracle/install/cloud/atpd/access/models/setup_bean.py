from oracle.install.cloud.atpd.access.models.access_setup_bean import AccessSetupBean
from oracle.install.cloud.atpd.access.models.oci_bean import OCIBean


class SetupBean:

    def __init__(self):
        self._raw_data=None
        self._processed_data=None
        self._access_setup_bean=AccessSetupBean()
        self._oci_connection_data = {}
        self._oci_bean=OCIBean()

    def set_raw_data(self,raw_data):
        self._raw_data=raw_data

    def get_raw_data(self):
        return self._raw_data

    def set_processed_data(self,processed_data):
        self._processed_data=processed_data

    def get_processed_data(self):
        return self._processed_data

    def set_access_setup_bean(self,access_setup_bean):
        self._access_setup_bean=access_setup_bean

    def get_access_setup_bean(self):
        return self._access_setup_bean

    def set_oci_connection_data(self,oci_connection_data):
        self._oci_connection_data=oci_connection_data

    def get_oci_connection_data(self):
        return self._oci_connection_data

    def get_oci_bean(self):
        return self._oci_bean

    def set_oci_bean(self,oci_bean):
        self._oci_bean=oci_bean
