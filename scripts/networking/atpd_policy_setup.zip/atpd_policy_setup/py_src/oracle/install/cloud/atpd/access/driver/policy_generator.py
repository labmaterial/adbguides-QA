import logging

from oracle.install.cloud.atpd.access.resource.setup_constants import SetupConstants
from oracle.install.cloud.common.resource.atpd_exception import ATPDException
from oracle.install.cloud.common.resource.user_messages import UserMessages


class PolicyGenerator:
    """
    Generates the policies
    """

    def generate_policies(self,access_setup_bean):
        """
        Generate the policies based on the information provided by the user
        :param access_setup_bean: (SetupBean)
        :return:
        """
        policies=[]
        fleet_compartment_policy_statements={}
        if not access_setup_bean.get_policies():
            # Generate policies to define access rule for fleet admin groups
            if access_setup_bean.get_fleet_admin_groups():
                for fleet_admin_group in access_setup_bean.get_fleet_admin_groups():
                    group_name=fleet_admin_group[SetupConstants.GROUP_NAME_PROPERTY]
                    policy_definition={}
                    policy_definition[SetupConstants.POLICY_NAME_PROPERTY]=group_name+"_policy"
                    policy_definition[SetupConstants.POLICY_DESCRIPTION_PROPERTY]="Policy to define access rule for fleet admin group "+group_name
                    policy_definition[SetupConstants.POLICY_STATEMENTS_PROPERTY]=[]
                    if SetupConstants.FLEET_COMPARTMENTS_PROPERTY in fleet_admin_group and fleet_admin_group[SetupConstants.FLEET_COMPARTMENTS_PROPERTY]:
                        compartments=fleet_admin_group[SetupConstants.FLEET_COMPARTMENTS_PROPERTY]
                        fleet_compartments=[]
                        if isinstance(compartments, list):
                            fleet_compartments=compartments
                        else:
                            fleet_compartments.extend(compartments.split(","))
                        for fleet_compartment in fleet_compartments:
                            statements=self.get_fleet_admin_policy_statements(fleet_admin_group[SetupConstants.GROUP_NAME_PROPERTY],fleet_compartment.strip())
                            policy_definition[SetupConstants.POLICY_STATEMENTS_PROPERTY].extend(statements)
                            fleet_compartment_policy_statements[fleet_compartment.strip()]=policy_definition[SetupConstants.POLICY_STATEMENTS_PROPERTY]
                    policies.append(policy_definition)
            # Generate policies to define access rule for dba groups
            if access_setup_bean.get_dba_groups():
                for dba_group in access_setup_bean.get_dba_groups():
                    group_name=dba_group[SetupConstants.GROUP_NAME_PROPERTY]
                    policy_definition={}
                    policy_definition[SetupConstants.POLICY_NAME_PROPERTY]=group_name+"_policy"
                    policy_definition[SetupConstants.POLICY_DESCRIPTION_PROPERTY]="Policy to define access rule for dba group "+group_name
                    policy_definition[SetupConstants.POLICY_STATEMENTS_PROPERTY]=[]
                    if SetupConstants.DBA_COMPARTMENTS_PROPERTY in dba_group and dba_group[SetupConstants.DBA_COMPARTMENTS_PROPERTY]:
                        compartments=dba_group[SetupConstants.DBA_COMPARTMENTS_PROPERTY]
                        dba_compartments=[]
                        if isinstance(compartments, list):
                            dba_compartments=compartments
                        else:
                            dba_compartments.extend(compartments.split(","))

                        for dba_compartment in dba_compartments:
                            statements=self.get_dba_policy_statements(dba_group[SetupConstants.GROUP_NAME_PROPERTY],dba_compartment.strip())
                            policy_definition[SetupConstants.POLICY_STATEMENTS_PROPERTY].extend(statements)

                    if SetupConstants.FLEET_COMPARTMENTS_PROPERTY in dba_group and dba_group[SetupConstants.FLEET_COMPARTMENTS_PROPERTY]:
                        compartments=dba_group[SetupConstants.FLEET_COMPARTMENTS_PROPERTY]
                        fleet_compartments=[]
                        if isinstance(compartments, list):
                            fleet_compartments=compartments
                        else:
                            fleet_compartments.extend(compartments.split(","))
                        for fleet_compartment in fleet_compartments:
                            if fleet_compartment.strip() in fleet_compartment_policy_statements:
                                self.add_fleet_compartment_access_policy_statements(fleet_compartment_policy_statements[fleet_compartment.strip()],group_name,fleet_compartment.strip())
                            else:
                                raise ATPDException(UserMessages.format_message(UserMessages.UNABLE_TO_FIND_FLEET_POLICY_TO_ADD_DBA_ACCESS_STATEMENTS, dba_group=group_name, fleet_compartment=fleet_compartment.strip()))

                    policies.append(policy_definition)
            access_setup_bean.set_policies(policies)
        else:
            logging.info("Policies are already defined. So skipping the policy generation")



    def get_fleet_admin_policy_statements(self,group_name,compartment_name):
        """
        Generate fleet admin policies statements
        :param group_name: (String)
        :param compartment_name: (String)
        :return: (list) The list of statements
        """
        statements=[]
        statements.append("Allow group "+group_name+" to MANAGE autonomous-exadata-infrastructures in compartment "+compartment_name)
        statements.append("Allow group "+group_name+" to MANAGE autonomous-container-databases in compartment "+compartment_name)
        statements.append("Allow group "+group_name+" to USE virtual-network-family in compartment "+compartment_name)
        return statements

    def get_dba_policy_statements(self,group_name,compartment_name):
        """
        Generate dba policies statements
        :param group_name:
        :param compartment_name:
        :return: (list) The list of statements
        """
        statements=[]
        statements.append("Allow group "+group_name+" to MANAGE autonomous-databases in compartment "+compartment_name)
        statements.append("Allow group "+group_name+" to MANAGE autonomous-backups in compartment "+compartment_name)
        statements.append("Allow group "+group_name+" to USE virtual-network-family in compartment "+compartment_name)
        statements.append("Allow group "+group_name+" to MANAGE instance-family in compartment "+compartment_name)
        statements.append("Allow group "+group_name+" to inspect tag-namespaces on tenancy")
        return statements

    def add_fleet_compartment_access_policy_statements(self,fleet_policy_statements,dba_group_name,fleet_compartment):
        """
        Generate the policy to use CDBs
        :param fleet_policy_statements: (list) The list of fleet admin policies statements
        :param dba_group_name: (String)
        :param fleet_compartment: (String)
        :return: (list) The list of statements
        """
        if fleet_policy_statements:
            fleet_policy_statements.append("Allow group "+dba_group_name+" to READ autonomous-container-databases in compartment "+fleet_compartment)
