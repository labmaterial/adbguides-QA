import os
import logging

from oci.config import validate_config, from_file
from oci.exceptions import InvalidConfig, ConfigFileNotFound

from oracle.install.cloud.common.resource.common_constants import CommonConstants
from oracle.install.cloud.common.yaml.yaml_loader import YAMLLoader
from oracle.install.cloud.common.resource.atpd_exception import ATPDException
from oracle.install.cloud.common.resource.user_messages import UserMessages
from oracle.install.cloud.atpd.access.resource.setup_constants import SetupConstants

class OCIConnectionLoader:
    """
    Loads the OCI connection data
    """

    def _load_from_oci_directory(self):
        """
        Loads the connection data from the default OCI configuration location
        :return:
        """
        oci_config_file = SetupConstants.OCI_CONFIG_FILE
        connection_data = from_file(file_location=oci_config_file)
        oci_connection_data = {
            CommonConstants.OCI_USER_PROPERTY: connection_data[CommonConstants.OCI_USER_PROPERTY],
            CommonConstants.OCI_REGION_PROPERTY: connection_data[CommonConstants.OCI_REGION_PROPERTY],
            CommonConstants.OCI_TENANCY_PROPERTY: connection_data[CommonConstants.OCI_TENANCY_PROPERTY],
            CommonConstants.OCI_KEY_FILE_PROPERTY: connection_data[CommonConstants.OCI_KEY_FILE_PROPERTY],
            CommonConstants.OCI_FINGERPRINT_PROPERTY: connection_data[CommonConstants.OCI_FINGERPRINT_PROPERTY]
        }
        complete_object = all(value for value in oci_connection_data.values())
        if complete_object:
            return oci_connection_data

    def _load_from_default_template(self):
        """
        Loads the connection data from the default YAML template
        :return:
        """
        default_template = os.path.join(SetupConstants.TEMPLATES_DIRECTORY, SetupConstants.DEFAULT_YAML_TEMPLATE_NAME)
        if default_template:
            if os.path.exists(default_template):
                raw_data = YAMLLoader().load_yaml(default_template)
                oci_connection_data = raw_data[SetupConstants.OCI_CONNECTION_PROPERTY]
                complete_object = all(value for value in oci_connection_data.values())
                if complete_object:
                    return oci_connection_data
            else:
                raise ATPDException(UserMessages.format_message(UserMessages.YAML_FILE_DOESNOT_EXISTS, yaml_file=default_template))
        else:
            raise ATPDException(UserMessages.format_message(UserMessages.YAML_FILE_NOT_SPECIFIED))

    def _load_from_original_file(self, raw_data):
        """
        Loads the connection data from the provided YAML file
        :param raw_data: (dict)
        :return:
        """
        oci_connection_data = raw_data[SetupConstants.OCI_CONNECTION_PROPERTY]
        complete_object = all(value for value in oci_connection_data.values())
        if complete_object:
            return oci_connection_data

    def _load_oci_connection_from_all_sources(self,processed_raw_data):
        """
        Load the OCI connection data
        :param proccessed_raw_data: (dict)
        :return:
        """
        # First, try to get connection data from passed file
        logging.info("Loading connection data from provided YAML")
        oci_connection_data= self._load_from_original_file(processed_raw_data)
        if oci_connection_data:
            return oci_connection_data
        # Second, try to get it from the default yaml template
        logging.info("Loading connection data from default template")
        oci_connection_data = self._load_from_default_template()
        if oci_connection_data:
            return oci_connection_data
        # Finally, get them from ~/.oci/config
        logging.info("Loading connection data from oci directory: " + SetupConstants.OCI_CONFIG_FILE)
        return self._load_from_oci_directory()


    def load_oci_connection_data(self, proccessed_raw_data):
        """
        Load the OCI connection data
        :param proccessed_raw_data: (dict)
        :return:
        """
        oci_connection_data=self._load_oci_connection_from_all_sources(proccessed_raw_data)
        if oci_connection_data and isinstance(oci_connection_data, dict):
            if CommonConstants.OCI_REGION_PROPERTY in oci_connection_data:
                if oci_connection_data[CommonConstants.OCI_REGION_PROPERTY] == "r1" or oci_connection_data[CommonConstants.OCI_REGION_PROPERTY] == "us-seattle-1":
                    oci_connection_data[CommonConstants.OCI_REGION_PROPERTY]="r1.oracleiaas.com"
            # R1 variables
            if CommonConstants.REQUESTS_CA_BUNDLE_PROPERTY in oci_connection_data and oci_connection_data[CommonConstants.REQUESTS_CA_BUNDLE_PROPERTY]:
                os.environ[CommonConstants.REQUESTS_CA_BUNDLE_PROPERTY] = oci_connection_data[CommonConstants.REQUESTS_CA_BUNDLE_PROPERTY]
                del oci_connection_data[CommonConstants.REQUESTS_CA_BUNDLE_PROPERTY]
            if CommonConstants.R1_CERT_LOCATION_PROPERTY in os.environ and oci_connection_data[CommonConstants.R1_CERT_LOCATION_PROPERTY]:
                os.environ[CommonConstants.R1_CERT_LOCATION_PROPERTY] = oci_connection_data[CommonConstants.R1_CERT_LOCATION_PROPERTY]
                del oci_connection_data[CommonConstants.R1_CERT_LOCATION_PROPERTY]
        return oci_connection_data
