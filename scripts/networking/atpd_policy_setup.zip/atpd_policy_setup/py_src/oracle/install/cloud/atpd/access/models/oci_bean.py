
class OCIBean:

    def __init__(self):
        self._users=[]
        self._groups=[]
        self._policies=[]

    def set_users(self,users):
        self._users=users

    def get_users(self):
        return self._users

    def set_groups(self,groups):
        self._groups=groups

    def get_groups(self):
        return self._groups

    def set_policies(self,policies):
        self._policies=policies

    def get_policies(self):
        return self._policies


