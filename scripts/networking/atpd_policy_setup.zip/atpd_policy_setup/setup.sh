#!/bin/bash

# PRE-REQS:
# 1. Python 2.7.5 or greater

# Set path if path not set
case $PATH in
    "") PATH=/bin:/usr/bin:/sbin:/etc
        export PATH ;;
esac

#Initial time
START_TIME=`date +%s`

CURRENT_LOCATION=`pwd`

DIRNAME="/usr/bin/dirname";
cd "`${DIRNAME} $0`";
DEPLOY_SCRIPT_LOCATION="`pwd -L`";
cd $DEPLOY_SCRIPT_LOCATION/..
PROJECT_LOCATION="`pwd -L`";
TIMESTAMP=`date +%m%d%Y-%H%M%S`

#Get arguments
arguments=""
for ARGUMENT in "$@"
do
    KEY=$(echo $ARGUMENT | cut -f1 -d=)
    VALUE=$(echo $ARGUMENT | cut -f2 -d=)
    arguments="${arguments} ${KEY}=${VALUE}"
done

#Create project's logs
PROJECT_LOCATION_LOGS=$DEPLOY_SCRIPT_LOCATION/logs
mkdir -p $PROJECT_LOCATION_LOGS
LOG_FILE="$PROJECT_LOCATION_LOGS/atpd-policy-setup_$TIMESTAMP.log"
touch $LOG_FILE

#Install dependencies
echo "Installing dependencies" | tee $LOG_FILE
PYTHON_VERSION=`python -c 'import platform; print(platform.python_version())'`
echo "Python version is $PYTHON_VERSION" >> $LOG_FILE
version=$(echo $PYTHON_VERSION | grep -o '[^-]*$')
major=$(echo $version | cut -d. -f1)
if [ "$major" == "2" ]
then
    if ! [ -x "$(command -v virtualenv)" ]
    then
        echo "Required python package 'virtualenv' is not installed or not available in the PATH."
        exit 1
    fi
    if ! [ -x "$(command -v pip)" ]
    then
        echo "Required package 'pip' is not installed or not available in the PATH."
        exit 1
    fi
    python -m virtualenv $DEPLOY_SCRIPT_LOCATION/pyenv >> $LOG_FILE 2>&1
fi
if [ "$major" == "3" ]
then
    if ! [ -x "$(command -v pip)" ]
    then
        echo "Required package 'pip' is not installed or not available in the PATH."
        exit 1
    fi
    python -m venv $DEPLOY_SCRIPT_LOCATION/pyenv >> $LOG_FILE 2>&1
fi
if ! [ -f $DEPLOY_SCRIPT_LOCATION/pyenv/bin/activate ]
then 
    echo "Python virtual environment creation failed"
    exit 1
fi
source $DEPLOY_SCRIPT_LOCATION/pyenv/bin/activate
python -m pip install pyyaml >> $LOG_FILE 2>&1
python -m pip install oci >> $LOG_FILE  2>&1
echo "Finishing installing dependencies" | tee -a $LOG_FILE

#Call python
export PYTHONPATH=$DEPLOY_SCRIPT_LOCATION/py_src/
export PROJECT_HOME=$DEPLOY_SCRIPT_LOCATION
python $DEPLOY_SCRIPT_LOCATION/py_src/oracle/install/cloud/atpd/access/driver/setup.py $arguments --timestamp=$TIMESTAMP
exit_code=$?
cd $CURRENT_LOCATION
if [ $exit_code != 0 ]
then
    exit $exit_code
fi

#Final time
END_TIME=`date +%s`
RUNTIME=$((END_TIME-START_TIME))
echo "Run time (seconds): $RUNTIME" | tee -a $LOG_FILE
exit 0
